TrueCall Pro - Android Trial Project

महत्वपूर्ण:
- यह APK नहीं, Android Studio का source project है।
- यह केवल demo app है और तीन sample numbers पर काम करता है।
- यह असली Caller ID, contacts access, call log access या call blocking नहीं करता।
- किसी भी असली नंबर की पहचान का दावा नहीं करता।

APK बनाने के लिए:
1. कंप्यूटर पर Android Studio इंस्टॉल करें।
2. इस ZIP को extract करें और Android Studio में project folder खोलें।
3. Gradle sync पूरा होने दें (इंटरनेट जरूरी हो सकता है)।
4. Build > Build Bundle(s) / APK(s) > Build APK(s) चुनें।
5. APK आम तौर पर app/build/outputs/apk/debug/app-debug.apk में बनेगा।

Play Store पर डालने से पहले:
- App name, icon, screenshots और store listing तैयार करें।
- Privacy policy और Data safety form सही-सही भरें।
- Target API और Google Play की मौजूदा testing/policy requirements जाँचें।
- इस demo को असली caller identification product बताकर publish न करें।
