package com.truecallpro.demo

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*

class MainActivity : Activity() {
    private val demoNumbers = mapOf(
        "9876543210" to Pair("Demo Contact - Rahul", false),
        "9123456780" to Pair("Suspected Spam (Demo)", true),
        "9000011111" to Pair("Demo Contact - Priya", false)
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val bg = 0xFFF5F7FB.toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 36, 24, 24)
            setBackgroundColor(bg)
        }

        val title = TextView(this).apply {
            text = "TrueCall Pro"
            textSize = 28f
            setTextColor(0xFF172554.toInt())
            gravity = Gravity.CENTER
        }
        root.addView(title, matchWrap())

        val subtitle = TextView(this).apply {
            text = "Caller ID & Spam Check • Trial Demo"
            textSize = 14f
            setTextColor(Color.DKGRAY)
            gravity = Gravity.CENTER
            setPadding(0, 8, 0, 28)
        }
        root.addView(subtitle, matchWrap())

        val input = EditText(this).apply {
            hint = "Enter 10-digit mobile number"
            inputType = 2
            setSingleLine(true)
            textSize = 16f
            setPadding(16, 12, 16, 12)
            setBackgroundColor(Color.WHITE)
        }
        root.addView(input, matchWrap())

        val search = Button(this).apply { text = "Check Number" }
        val result = TextView(this).apply {
            text = "Try demo numbers:\n9876543210\n9123456780\n9000011111"
            textSize = 17f
            setTextColor(0xFF334155.toInt())
            setPadding(16, 24, 16, 24)
        }
        root.addView(search, matchWrap(18))
        root.addView(result, matchWrap())

        search.setOnClickListener {
            val number = input.text.toString().trim()
            val entry = demoNumbers[number]
            result.text = when {
                number.length != 10 || !number.all { it.isDigit() } ->
                    "Please enter a valid 10-digit number."
                entry == null ->
                    "No demo record found. This trial app uses sample data only."
                entry.second ->
                    "⚠ ${entry.first}\nReport status: Demo spam label"
                else ->
                    "✓ ${entry.first}\nNumber status: Demo contact"
            }
        }

        val note = TextView(this).apply {
            text = "Privacy note: This trial uses only three built-in sample records. It does not access contacts, read call logs, identify real callers, or block calls."
            textSize = 12f
            setTextColor(0xFF64748B.toInt())
            setPadding(0, 24, 0, 0)
        }
        root.addView(note, matchWrap())
        setContentView(ScrollView(this).apply { addView(root) })
    }

    private fun matchWrap(top: Int = 0) =
        LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            if (top > 0) topMargin = top
        }
}
