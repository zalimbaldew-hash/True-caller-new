plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.truecallpro.demo"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.truecallpro.demo"
        minSdk = 23
        targetSdk = 35
        versionCode = 1
        versionName = "0.1"
    }
}
